<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Attendance</h1></div></div>
<div class="grid-2">
<section class="card"><form method="post" action="<?php echo e(route('attendance.store')); ?>"><?php echo csrf_field(); ?>
    <div class="field"><label>Employee</label><select name="employee_id"><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="field"><label>Date</label><input type="date" name="attended_on" value="<?php echo e(now()->toDateString()); ?>"></div>
    <div class="field"><label>Status</label><select name="status"><option>present</option><option>absent</option><option>leave</option></select></div>
    <div class="field"><label>Check in</label><input name="check_in" placeholder="09:00"></div>
    <div class="field"><label>Check out</label><input name="check_out" placeholder="18:00"></div>
    <button class="btn primary">Save</button>
</form></section>
<section class="card"><table><thead><tr><th>Date</th><th>Employee</th><th>Status</th><th>In</th><th>Out</th></tr></thead>
<tbody><?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($row->attended_on->format('d M Y')); ?></td><td><?php echo e($row->employee->name); ?></td><td><?php echo e($row->status); ?></td><td><?php echo e($row->check_in); ?></td><td><?php echo e($row->check_out); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="5" class="empty">No attendance yet.</td></tr><?php endif; ?></tbody></table><?php echo e($rows->links()); ?></section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/hrm/attendance.blade.php ENDPATH**/ ?>