<?php $__env->startSection('content'); ?>
<div class="page-title"><div><div class="crumbs">Product › <?php echo e($product->name); ?></div><h1><?php echo e($product->name); ?></h1></div>
    <div class="filters"><a class="btn" href="<?php echo e(route('products.edit', $product)); ?>">Edit</a><a class="btn" href="<?php echo e(route('products.index')); ?>">Back</a></div>
</div>
<div class="grid-2">
    <section class="card">
        <?php if($product->image): ?><img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="" style="width:160px;border-radius:12px"><?php endif; ?>
        <p>Code <?php echo e($product->code); ?> · <?php echo e(ucfirst($product->type)); ?></p>
        <p>Brand <?php echo e($product->brand->name ?? '—'); ?> · Category <?php echo e($product->category->name ?? '—'); ?> · Unit <?php echo e($product->unit->name ?? '—'); ?></p>
        <p>Cost <?php echo \App\Support\Money::format((int) ($product->cost_cents), $moneySymbol ?? '$'); ?> · Price <?php echo \App\Support\Money::format((int) ($product->sellingPriceCents()), $moneySymbol ?? '$'); ?></p>
        <p>Stock <span class="badge <?php echo e($product->isLowStock() ? 'bad' : 'ok'); ?>"><?php echo e($product->stock_qty); ?></span> · Alert <?php echo e($product->alert_qty); ?></p>
        <p><?php echo e($product->description); ?></p>
        <?php if($product->variants->isNotEmpty()): ?>
            <h2>Variants</h2>
            <ul><?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($variant->name); ?> · <?php echo e($variant->sku); ?> · <?php echo \App\Support\Money::format((int) ($variant->price_cents), $moneySymbol ?? '$'); ?> · stock <?php echo e($variant->stock_qty); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
        <?php endif; ?>
    </section>
    <section class="card">
        <h2>Inventory history</h2>
        <table>
            <thead><tr><th>When</th><th>Reason</th><th>Change</th><th>Balance</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $product->movements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr><td><?php echo e($movement->created_at->format('d M Y H:i')); ?></td><td><?php echo e($movement->reason); ?></td><td><?php echo e($movement->qty_change); ?></td><td><?php echo e($movement->balance_after); ?></td></tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="4" class="empty">No stock movements yet.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/products/show.blade.php ENDPATH**/ ?>