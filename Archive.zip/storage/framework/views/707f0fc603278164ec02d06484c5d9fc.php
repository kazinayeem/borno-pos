<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Subscription Purchase</h1></div></div>
<div class="cards-3">
<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <section class="card">
        <h2><?php echo e($plan->name); ?></h2>
        <strong><?php echo \App\Support\Money::format((int) ($plan->price_cents), $moneySymbol ?? '$'); ?></strong>
        <p><?php echo e($plan->features); ?></p>
        <form method="post" action="<?php echo e(route('subscriptions.buy')); ?>"><?php echo csrf_field(); ?>
            <input type="hidden" name="plan_id" value="<?php echo e($plan->id); ?>">
            <button class="btn primary">Request plan</button>
        </form>
    </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<section class="card" style="margin-top:14px"><h2>Recent requests</h2>
<table><thead><tr><th>Plan</th><th>Status</th><th>Payment</th></tr></thead>
<tbody><?php $__empty_1 = true; $__currentLoopData = $current; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($row->plan->name); ?></td><td><?php echo e($row->status); ?></td><td><?php echo e($row->payment_status); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="3" class="empty">No subscription requests.</td></tr><?php endif; ?></tbody></table>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/subscriptions/purchase.blade.php ENDPATH**/ ?>