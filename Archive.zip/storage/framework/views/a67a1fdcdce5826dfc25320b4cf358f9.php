<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div>
        <div class="crumbs">Dashboard › <?php echo e($def['group']); ?> › <?php echo e($def['title']); ?></div>
        <h1><?php echo e($def['title']); ?></h1>
    </div>
    <a class="btn primary" href="<?php echo e(route($def['route'].'.create')); ?>">+ Add</a>
</div>
<section class="card">
    <form method="get" style="margin-bottom:12px"><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Search..." style="max-width:320px;border:1px solid #dbe3ee;border-radius:12px;padding:10px 12px"></form>
    <table>
        <thead>
            <tr>
                <th>SL</th>
                <?php $__currentLoopData = $def['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e($field['label']); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration + ($rows->currentPage()-1)*$rows->perPage()); ?></td>
                <?php $__currentLoopData = $def['fields']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td>
                        <?php $value = data_get($row, $field['name']); ?>
                        <?php if(($field['type'] ?? '') === 'money'): ?> <?php echo \App\Support\Money::format((int) ((int) $value), $moneySymbol ?? '$'); ?>
                        <?php elseif(($field['type'] ?? '') === 'checks'): ?> <?php echo e(implode(', ', $value ?? [])); ?>

                        <?php elseif(($field['type'] ?? '') === 'checkbox'): ?> <?php echo e($value ? 'Yes' : 'No'); ?>

                        <?php elseif(($field['type'] ?? '') === 'select' && isset($def['options'][$field['name']])): ?> <?php echo e($def['options'][$field['name']][$value] ?? $value); ?>

                        <?php else: ?> <?php echo e($value); ?>

                        <?php endif; ?>
                    </td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <td>
                    <a href="<?php echo e(route($def['route'].'.edit', $row->id)); ?>">Edit</a>
                    <form method="post" action="<?php echo e(route($def['route'].'.destroy', $row->id)); ?>" data-confirm="Delete this record?" style="display:inline"><?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?><button class="btn danger" type="submit">Delete</button></form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="<?php echo e(count($def['fields'])+2); ?>" class="empty">No records yet. Add the first <?php echo e(strtolower($def['singular'])); ?>.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="pager"><?php echo e($rows->links()); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/catalog/index.blade.php ENDPATH**/ ?>