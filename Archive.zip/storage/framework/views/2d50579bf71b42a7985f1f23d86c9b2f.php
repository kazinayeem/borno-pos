<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Profit & Loss</h1><div class="muted"><?php echo e($label); ?></div></div><?php echo $__env->make('partials.range', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<section class="card">
    <table>
        <tr><td>Sales including tax</td><td><?php echo \App\Support\Money::format((int) ($data['total_sales']), $moneySymbol ?? '$'); ?></td></tr>
        <tr><td>Sales returns including tax</td><td><?php echo \App\Support\Money::format((int) ($data['sales_return']), $moneySymbol ?? '$'); ?></td></tr>
        <tr><td>Gross profit (sales ex tax, minus unit cost, minus returns)</td><td><?php echo \App\Support\Money::format((int) ($data['gross_profit']), $moneySymbol ?? '$'); ?></td></tr>
        <tr><td>Expenses</td><td><?php echo \App\Support\Money::format((int) ($data['expense']), $moneySymbol ?? '$'); ?></td></tr>
        <tr><td>Salary</td><td><?php echo \App\Support\Money::format((int) ($data['salary']), $moneySymbol ?? '$'); ?></td></tr>
        <tr><th>Net profit</th><th><?php echo \App\Support\Money::format((int) ($data['net_profit']), $moneySymbol ?? '$'); ?></th></tr>
    </table>
    <p class="muted">Purchase invoices are not subtracted here. Their cost is recognized when the unit is sold.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/reports/profit.blade.php ENDPATH**/ ?>