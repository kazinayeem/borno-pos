<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Business Modules</h1></div></div>
<section class="card"><form method="post" action="<?php echo e(route('settings.modules.update')); ?>"><?php echo csrf_field(); ?>
    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $enabled): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label style="display:block;margin:8px 0"><input type="checkbox" name="<?php echo e($key); ?>" value="1" <?php if($enabled): echo 'checked'; endif; ?>> <?php echo e(ucfirst($key)); ?></label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <button class="btn primary">Save modules</button>
</form></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/settings/modules.blade.php ENDPATH**/ ?>