<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Print Barcode</h1></div></div>
<section class="card">
    <form method="get">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label style="display:inline-flex;gap:6px;margin:6px 12px 6px 0"><input type="checkbox" name="ids[]" value="<?php echo e($product->id); ?>" <?php if(in_array($product->id, request('ids', []))): echo 'checked'; endif; ?>> <?php echo e($product->name); ?> (<?php echo e($product->code); ?>)</label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <div><button class="btn primary" type="submit">Preview</button></div>
    </form>
    <div style="display:flex;flex-wrap:wrap;gap:12px;margin-top:16px">
        <?php $__currentLoopData = $selected; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div style="border:1px dashed #cbd5e1;padding:12px;border-radius:12px;text-align:center">
                <strong><?php echo e($product->name); ?></strong>
                <div style="font-family:monospace;letter-spacing:4px;font-size:20px;margin:8px 0"><?php echo e($product->code); ?></div>
                <div><?php echo \App\Support\Money::format((int) ($product->price_cents), $moneySymbol ?? '$'); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/products/barcode.blade.php ENDPATH**/ ?>