<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Transactions</h1></div></div>
<section class="card">
    <table><thead><tr><th>Date</th><th>Account</th><th>Description</th><th>Direction</th><th>Amount</th></tr></thead>
    <tbody><?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($row->transacted_on->format('d M Y')); ?></td><td><?php echo e($row->account->name ?? ''); ?></td><td><?php echo e($row->description); ?></td><td><?php echo e($row->direction); ?></td><td><?php echo \App\Support\Money::format((int) ($row->amount_cents), $moneySymbol ?? '$'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table>
    <?php echo e($transactions->links()); ?>

</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/accounting/transactions.blade.php ENDPATH**/ ?>