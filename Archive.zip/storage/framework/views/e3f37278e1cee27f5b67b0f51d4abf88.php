<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Shop Categories</h1></div></div>
<section class="card"><table><thead><tr><th>Business type</th><th>Shops</th></tr></thead>
<tbody><?php $__currentLoopData = $types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e(str_replace('_',' ', $type->business_type)); ?></td><td><?php echo e($type->total); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/shops/categories.blade.php ENDPATH**/ ?>