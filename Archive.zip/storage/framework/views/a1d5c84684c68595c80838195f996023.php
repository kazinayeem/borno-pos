<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Stock Count</h1></div></div>
<section class="card">
    <form method="post" action="<?php echo e(route('stock.store')); ?>" data-once><?php echo csrf_field(); ?>
        <div class="form-grid">
            <div class="field"><label>Warehouse</label><select name="warehouse_id"><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($warehouse->id); ?>"><?php echo e($warehouse->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
            <div class="field"><label>Date</label><input type="date" name="counted_on" value="<?php echo e(now()->toDateString()); ?>"></div>
        </div>
        <table><thead><tr><th>Product</th><th>Expected</th><th>Counted</th></tr></thead>
        <tbody><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($product->name); ?></td><td><?php echo e($product->stock_qty); ?></td><td><input type="number" min="0" name="counted[<?php echo e($product->id); ?>]" value="<?php echo e($product->stock_qty); ?>"></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table>
        <button class="btn primary">Apply count</button>
    </form>
</section>
<section class="card" style="margin-top:12px"><table><thead><tr><th>Date</th><th>Status</th></tr></thead><tbody><?php $__currentLoopData = $counts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($count->counted_on->format('d M Y')); ?></td><td><?php echo e($count->status); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/stock/index.blade.php ENDPATH**/ ?>