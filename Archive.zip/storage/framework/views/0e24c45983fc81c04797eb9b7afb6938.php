<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Balance Sheet</h1></div></div>
<section class="card">
    <table>
        <tbody>
            <tr><td>Cash and bank</td><td><?php echo \App\Support\Money::format((int) ($cash), $moneySymbol ?? '$'); ?></td></tr>
            <tr><td>Inventory at cost</td><td><?php echo \App\Support\Money::format((int) ($inventory), $moneySymbol ?? '$'); ?></td></tr>
            <tr><td>Customer due (asset)</td><td><?php echo \App\Support\Money::format((int) ($salesDue), $moneySymbol ?? '$'); ?></td></tr>
            <tr><td>Purchase due (liability)</td><td><?php echo \App\Support\Money::format((int) ($purchaseDue), $moneySymbol ?? '$'); ?></td></tr>
            <tr><th>Equity</th><th><?php echo \App\Support\Money::format((int) ($cash + $inventory + $salesDue - $purchaseDue), $moneySymbol ?? '$'); ?></th></tr>
        </tbody>
    </table>
    <p class="muted">Inventory uses current stock times product cost. Purchase totals are not deducted a second time.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/accounting/balance.blade.php ENDPATH**/ ?>