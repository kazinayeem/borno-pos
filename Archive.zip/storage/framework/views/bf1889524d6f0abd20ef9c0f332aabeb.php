<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Profile</h1></div></div>
<section class="card"><form method="post" action="<?php echo e(route('profile.update')); ?>"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
    <div class="field"><label>Name</label><input name="name" value="<?php echo e(old('name', auth()->user()->name)); ?>" required></div>
    <div class="field"><label>Email</label><input name="email" value="<?php echo e(old('email', auth()->user()->email)); ?>" required></div>
    <div class="field"><label>Phone</label><input name="phone" value="<?php echo e(old('phone', auth()->user()->phone)); ?>"></div>
    <div class="field"><label>New password</label><input type="password" name="password"></div>
    <div class="field"><label>Confirm password</label><input type="password" name="password_confirmation"></div>
    <button class="btn primary">Save profile</button>
</form></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/settings/profile.blade.php ENDPATH**/ ?>