<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Take a Tour</h1></div></div>
<section class="card">
    <ol>
        <li><a href="<?php echo e(route('products.create')); ?>">Add a product</a> with a code, price, and optional photo.</li>
        <li><a href="<?php echo e(route('purchases.create')); ?>">Record a purchase</a> so stock increases.</li>
        <li><a href="<?php echo e(route('pos')); ?>">Open POS</a>, add items, take cash, and save the invoice.</li>
        <li><a href="<?php echo e(route('sales.index')); ?>">Review the sale</a>, print the receipt, or return items.</li>
        <li><a href="<?php echo e(route('reports.profit')); ?>">Check profit</a> for the same dates as the dashboard.</li>
    </ol>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/tour.blade.php ENDPATH**/ ?>