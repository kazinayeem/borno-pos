<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Accounts</h1></div></div>
<div class="grid-2">
<section class="card">
    <table><thead><tr><th>Name</th><th>Number</th><th>Type</th><th>Balance</th></tr></thead>
    <tbody><?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($account->name); ?></td><td><?php echo e($account->number); ?></td><td><?php echo e($account->type); ?></td><td><?php echo \App\Support\Money::format((int) ($account->balance), $moneySymbol ?? '$'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="empty">No accounts yet.</td></tr><?php endif; ?></tbody></table>
</section>
<section class="card">
    <h2>New account</h2>
    <form method="post" action="<?php echo e(route('accounts.store')); ?>"><?php echo csrf_field(); ?>
        <div class="field"><label>Name</label><input name="name" required></div>
        <div class="field"><label>Number</label><input name="number"></div>
        <div class="field"><label>Type</label><select name="type"><option value="cash">Cash</option><option value="bank">Bank</option><option value="mobile">Mobile</option></select></div>
        <div class="field"><label>Opening balance</label><input name="opening" value="0.00"></div>
        <button class="btn primary">Save</button>
    </form>
</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/accounting/accounts.blade.php ENDPATH**/ ?>