<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Stores</h1></div><a class="btn primary" href="<?php echo e(auth()->user()->isSuperAdmin() ? route('shops.create') : route('stores.create')); ?>">+ Create</a></div>
<section class="card"><table><thead><tr><th>Name</th><th>Type</th><th>Email</th><th>Status</th></tr></thead>
<tbody><?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($store->name); ?></td><td><?php echo e(str_replace('_', ' ', $store->business_type)); ?></td><td><?php echo e($store->email); ?></td><td><?php echo e($store->is_active ? 'Active' : 'Inactive'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody></table><?php echo e($stores->links()); ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/shops/index.blade.php ENDPATH**/ ?>