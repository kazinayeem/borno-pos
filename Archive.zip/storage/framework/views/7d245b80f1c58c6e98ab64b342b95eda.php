<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($title ?? 'BornoPos'); ?></title>
    <script>
        try {
            if (localStorage.getItem('bornopos-theme') === 'dark') {
                document.documentElement.classList.add('dark');
            }
        } catch (e) {}
    </script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <?php echo $__env->yieldPushContent('head'); ?>
</head>
<body>
<div class="app">
    <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="main">
        <header class="topbar">
            <button class="icon-btn hamburger" type="button" data-sidebar aria-label="Menu">☰</button>
            <form class="search" action="<?php echo e(route('search')); ?>" method="get">
                <?php echo $__env->make('partials.icon', ['name' => 'search'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <input name="q" value="<?php echo e(request('q')); ?>" placeholder="<?php echo e(__('Search product, invoice, customer...')); ?>">
                <kbd>⌘K</kbd>
            </form>
            <?php if (! (auth()->user()->isSuperAdmin())): ?>
                <a class="pos-btn" href="<?php echo e(route('pos')); ?>"><?php echo $__env->make('partials.icon', ['name' => 'cart'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> POS</a>
            <?php endif; ?>
            <button class="icon-btn round" type="button" data-theme title="Theme">☾</button>
            <div class="menu">
                <button class="icon-btn round" type="button" data-menu aria-label="Notifications">
                    🔔
                    <?php if(auth()->user()->notices()->whereNull('read_at')->count()): ?>
                        <span class="dot"><?php echo e(auth()->user()->notices()->whereNull('read_at')->count()); ?></span>
                    <?php endif; ?>
                </button>
                <div class="menu-pop">
                    <?php $__empty_1 = true; $__currentLoopData = auth()->user()->notices()->latest()->limit(5)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <div style="padding:8px 10px"><strong><?php echo e($notice->title); ?></strong><div class="muted"><?php echo e($notice->body); ?></div></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div class="muted" style="padding:8px 10px">No notifications</div>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('notices.read')); ?>"><?php echo csrf_field(); ?><button type="submit">Mark read</button></form>
                </div>
            </div>
            <div class="menu">
                <button class="lang" type="button" data-menu><span class="flag"><?php echo e(['en' => '🇬🇧', 'bn' => '🇧🇩', 'ar' => '🇸🇦'][app()->getLocale()] ?? '🇬🇧'); ?></span> <?php echo e(['en' => 'English', 'bn' => 'বাংলা', 'ar' => 'العربية'][app()->getLocale()] ?? 'English'); ?></button>
                <div class="menu-pop">
                    <a href="<?php echo e(route('locale', ['ln' => 'en'])); ?>">English</a>
                    <a href="<?php echo e(route('locale', ['ln' => 'bn'])); ?>">Bangla</a>
                    <a href="<?php echo e(route('locale', ['ln' => 'ar'])); ?>">Arabic</a>
                </div>
            </div>
            <div class="menu">
                <button class="user-chip" type="button" data-menu>
                    <span class="avatar"><?php echo e(strtoupper(substr(auth()->user()->name,0,1))); ?></span>
                    <span class="who"><b><?php echo e(auth()->user()->name); ?></b><small><?php echo e(ucfirst(str_replace('_', ' ', auth()->user()->role))); ?></small></span>
                </button>
                <div class="menu-pop">
                    <a href="<?php echo e(route('profile')); ?>">Profile</a>
                    <?php if (! (auth()->user()->isSuperAdmin())): ?>
                        <a href="<?php echo e(route('settings.general')); ?>">Settings</a>
                    <?php endif; ?>
                    <form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Logout</button></form>
                </div>
            </div>
        </header>
        <div class="content">
            <?php if(session('status')): ?><div class="flash"><?php echo e(session('status')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="errors">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <footer class="app-foot">
            <span>© <?php echo e(date('Y')); ?> BornoPos</span>
            <span><?php echo e(config('bornopos.support_phone')); ?> · <?php echo e(config('bornopos.support_email')); ?></span>
            <span>v<?php echo e(config('bornopos.version')); ?></span>
        </footer>
    </div>
</div>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/layouts/app.blade.php ENDPATH**/ ?>