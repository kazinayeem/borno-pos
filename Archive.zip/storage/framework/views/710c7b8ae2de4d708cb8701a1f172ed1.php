<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo e($sale->invoice_no); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
    <style>body{background:white;padding:24px} @media print {.no-print{display:none}}</style>
</head>
<body>
    <h1>BornoPos</h1>
    <p><?php echo e($sale->store->name ?? ''); ?> · <?php echo e($sale->store->address ?? ''); ?></p>
    <h2>Invoice <?php echo e($sale->invoice_no); ?></h2>
    <p><?php echo e($sale->sold_at->format('d M Y H:i')); ?> · <?php echo e($sale->customer->name ?? 'Walk-in Customer'); ?></p>
    <table>
        <thead><tr><th>Item</th><th>Qty</th><th>Price</th><th>Total</th></tr></thead>
        <tbody>
        <?php $__currentLoopData = $sale->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><td><?php echo e($item->product->name ?? 'Item'); ?></td><td><?php echo e($item->qty); ?></td><td><?php echo \App\Support\Money::format((int) ($item->price_cents), $moneySymbol ?? '$'); ?></td><td><?php echo \App\Support\Money::format((int) ($item->subtotal_cents), $moneySymbol ?? '$'); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <p>Discount <?php echo \App\Support\Money::format((int) ($sale->discount_cents), $moneySymbol ?? '$'); ?> · Tax <?php echo \App\Support\Money::format((int) ($sale->tax_cents), $moneySymbol ?? '$'); ?></p>
    <h3>Total <?php echo \App\Support\Money::format((int) ($sale->grand_cents), $moneySymbol ?? '$'); ?></h3>
    <p>Paid <?php echo \App\Support\Money::format((int) ($sale->paid_cents), $moneySymbol ?? '$'); ?> by <?php echo e($sale->payment_method); ?> · Due <?php echo \App\Support\Money::format((int) ($sale->dueCents()), $moneySymbol ?? '$'); ?></p>
    <p><?php echo e(\App\Models\Setting::withoutGlobalScopes()->where('store_id', $sale->store_id)->where('key','invoice_footer')->value('value')); ?></p>
    <button class="btn no-print" onclick="window.print()">Print</button>
</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/sales/print.blade.php ENDPATH**/ ?>