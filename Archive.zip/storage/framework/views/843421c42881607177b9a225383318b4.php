<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Summary</h1></div><?php echo $__env->make('partials.range', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<section class="card">
    <p>Total sales <?php echo \App\Support\Money::format((int) ($data['total_sales']), $moneySymbol ?? '$'); ?></p>
    <p>Returns <?php echo \App\Support\Money::format((int) ($data['sales_return']), $moneySymbol ?? '$'); ?></p>
    <p>Gross profit <?php echo \App\Support\Money::format((int) ($data['gross_profit']), $moneySymbol ?? '$'); ?></p>
    <p>Net profit <?php echo \App\Support\Money::format((int) ($data['net_profit']), $moneySymbol ?? '$'); ?></p>
    <p>Purchases <?php echo \App\Support\Money::format((int) ($data['purchase']), $moneySymbol ?? '$'); ?> · Due <?php echo \App\Support\Money::format((int) ($data['purchase_due']), $moneySymbol ?? '$'); ?></p>
    <p>Expenses <?php echo \App\Support\Money::format((int) ($data['expense']), $moneySymbol ?? '$'); ?> · Salary <?php echo \App\Support\Money::format((int) ($data['salary']), $moneySymbol ?? '$'); ?></p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/reports/summary.blade.php ENDPATH**/ ?>