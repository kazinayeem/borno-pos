<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Subscription Report</h1></div></div>
<section class="card"><table><thead><tr><th>Shop</th><th>Plan</th><th>Status</th><th>Payment</th><th>Amount</th><th></th></tr></thead>
<tbody><?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<tr><td><?php echo e($row->store->name ?? '—'); ?></td><td><?php echo e($row->plan->name ?? '—'); ?></td><td><?php echo e($row->status); ?></td><td><?php echo e($row->payment_status); ?></td><td><?php echo \App\Support\Money::format((int) ($row->amount_cents), $moneySymbol ?? '$'); ?></td>
<td><?php if(auth()->user()->isSuperAdmin() && $row->payment_status !== 'paid'): ?><form method="post" action="<?php echo e(route('subscriptions.activate', $row)); ?>"><?php echo csrf_field(); ?><button class="btn">Mark paid manually</button></form><?php endif; ?></td></tr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="6" class="empty">No subscriptions.</td></tr><?php endif; ?></tbody></table><?php echo e($rows->links()); ?></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/subscriptions/report.blade.php ENDPATH**/ ?>