<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Payment Gateway</h1></div></div>
<section class="card">
    <p class="muted">These switches record which methods your shop offers. BornoPos does not send charges to an external provider.</p>
    <form method="post" action="<?php echo e(auth()->user()->isSuperAdmin() ? route('gateway.admin.update') : route('settings.gateway.update')); ?>"><?php echo csrf_field(); ?>
        <?php $__currentLoopData = $names; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label style="display:block;margin:8px 0"><input type="checkbox" name="<?php echo e($key); ?>_enabled" value="1" <?php if($gateways[$key]['enabled'] ?? $key==='cash'): echo 'checked'; endif; ?>> <?php echo e($label); ?></label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="btn primary">Save methods</button>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/settings/gateway.blade.php ENDPATH**/ ?>