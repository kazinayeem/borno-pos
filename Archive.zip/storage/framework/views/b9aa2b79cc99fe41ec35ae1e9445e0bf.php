<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Sale Returns</h1></div><?php echo $__env->make('partials.range', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<section class="card">
    <table>
        <thead><tr><th>Date</th><th>Invoice</th><th>Total</th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $returns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $return): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr><td><?php echo e($return->returned_on->format('d M Y')); ?></td><td><a href="<?php echo e(route('sales.show', $return->sale_id)); ?>"><?php echo e($return->sale->invoice_no ?? $return->sale_id); ?></a></td><td><?php echo \App\Support\Money::format((int) ($return->grand_cents), $moneySymbol ?? '$'); ?></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="3" class="empty">No returns in this period.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="pager"><?php echo e($returns->links()); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/sales/returns.blade.php ENDPATH**/ ?>