<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Create a BornoPos shop</title>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
</head>
<body class="guest-body">
<div class="login-wrap" style="grid-template-columns:1fr;max-width:560px;margin:0 auto">
    <section class="login-card">
        <a href="<?php echo e(route('home')); ?>" style="display:flex;gap:8px;align-items:center;font-weight:800"><?php echo $__env->make('partials.logo', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> BornoPos</a>
        <h1>Create your shop</h1>
        <?php if($errors->any()): ?><div class="errors"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($error); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
        <form method="post" action="<?php echo e(route('signup.store')); ?>"><?php echo csrf_field(); ?>
            <div class="field"><label>Your name</label><input name="name" value="<?php echo e(old('name')); ?>" required></div>
            <div class="field"><label>Shop name</label><input name="shop_name" value="<?php echo e(old('shop_name')); ?>" required></div>
            <div class="field"><label>Business type</label>
                <select name="business_type">
                    <?php $__currentLoopData = ['all_in_one'=>'All in one','grocery'=>'Super shop / grocery','pharmacy'=>'Pharmacy','electronics'=>'Electronics or mobile shop','restaurant'=>'Restaurant']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($value); ?>" <?php if(old('business_type')===$value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="field"><label>Email</label><input type="email" name="email" value="<?php echo e(old('email')); ?>" required></div>
            <div class="field"><label>Password</label><input type="password" name="password" required></div>
            <div class="field"><label>Confirm password</label><input type="password" name="password_confirmation" required></div>
            <button class="btn primary" type="submit" style="width:100%">Create shop</button>
        </form>
        <p>Already registered? <a href="<?php echo e(route('signin')); ?>">Sign in</a></p>
    </section>
</div>
</body>
</html>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/auth/signup.blade.php ENDPATH**/ ?>