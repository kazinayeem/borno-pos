<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>General Settings</h1></div></div>
<section class="card"><form method="post" action="<?php echo e(route('settings.general.update')); ?>"><?php echo csrf_field(); ?>
    <div class="field"><label>Shop name</label><input name="shop_name" value="<?php echo e(old('shop_name', $store->name ?? '')); ?>" required></div>
    <div class="field"><label>Phone</label><input name="phone" value="<?php echo e(old('phone', $store->phone ?? '')); ?>"></div>
    <div class="field"><label>Address</label><input name="address" value="<?php echo e(old('address', $store->address ?? '')); ?>"></div>
    <div class="field"><label>Currency symbol</label><input name="currency_symbol" value="<?php echo e(old('currency_symbol', $store->currency_symbol ?? '$')); ?>" required></div>
    <div class="field"><label>Invoice footer</label><textarea name="invoice_footer"><?php echo e(old('invoice_footer', $settings['invoice_footer'] ?? '')); ?></textarea></div>
    <button class="btn primary">Save</button>
</form></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/settings/general.blade.php ENDPATH**/ ?>