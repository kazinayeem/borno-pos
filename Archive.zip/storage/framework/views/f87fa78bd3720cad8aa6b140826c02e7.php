<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Expense</h1></div><?php echo $__env->make('partials.range', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
<div class="grid-2">
<section class="card">
    <form method="post" action="<?php echo e(route('expenses.store')); ?>" enctype="multipart/form-data" data-once><?php echo csrf_field(); ?>
        <div class="field"><label>Category</label><select name="expense_category_id" required><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="field"><label>Account</label><select name="account_id"><option value="">Default cash</option><?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
        <div class="field"><label>Date</label><input type="date" name="spent_on" value="<?php echo e(now()->toDateString()); ?>" required></div>
        <div class="field"><label>Amount</label><input name="amount" required></div>
        <div class="field"><label>Note</label><input name="note"></div>
        <div class="field"><label>Attachment</label><input type="file" name="attachment"></div>
        <button class="btn primary">Save expense</button>
    </form>
</section>
<section class="card">
    <table><thead><tr><th>Date</th><th>Category</th><th>Note</th><th>Amount</th></tr></thead>
    <tbody><?php $__empty_1 = true; $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($expense->spent_on->format('d M Y')); ?></td><td><?php echo e($expense->category->name ?? '—'); ?></td><td><?php echo e($expense->note); ?></td><td><?php echo \App\Support\Money::format((int) ($expense->amount_cents), $moneySymbol ?? '$'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="empty">No expenses in this period.</td></tr><?php endif; ?></tbody></table>
    <?php echo e($expenses->links()); ?>

</section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/accounting/expenses.blade.php ENDPATH**/ ?>