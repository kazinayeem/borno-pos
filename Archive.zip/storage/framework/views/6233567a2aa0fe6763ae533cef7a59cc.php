<form class="filters" method="get">
    <?php $__currentLoopData = ['daily' => 'Today', 'weekly' => 'This Week', 'monthly' => 'This Month', 'yearly' => 'This Year']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button class="chip <?php echo e(request('type', request()->filled('from') ? '' : 'monthly') === $type && !request()->filled('from') ? 'active' : ''); ?>" name="type" value="<?php echo e($type); ?>"><?php echo e($text); ?></button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <span class="date-range">
        <input type="date" name="from" value="<?php echo e($from->toDateString()); ?>" aria-label="From">
        <span>–</span>
        <input type="date" name="to" value="<?php echo e($to->toDateString()); ?>" aria-label="To">
        <button type="submit">Apply</button>
    </span>
</form>
<?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/partials/range.blade.php ENDPATH**/ ?>