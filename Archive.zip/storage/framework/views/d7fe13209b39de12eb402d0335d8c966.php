<?php $__env->startSection('content'); ?>
<div class="page-title">
    <div><div class="crumbs">Dashboard › Product › <?php echo e($product->exists ? 'Edit' : 'New'); ?> Product</div><h1><?php echo e($product->exists ? 'Edit Product' : 'New Product'); ?></h1></div>
    <a class="btn" href="<?php echo e(route('products.index')); ?>">Back to Products</a>
</div>
<form method="post" action="<?php echo e($product->exists ? route('products.update', $product) : route('products.store')); ?>" enctype="multipart/form-data" data-once>
    <?php echo csrf_field(); ?>
    <?php if($product->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid-2">
        <section class="card">
            <h2>Basic Information</h2>
            <div class="form-grid">
                <div class="field"><label>Product Name *</label><input name="name" value="<?php echo e(old('name', $product->name)); ?>" required></div>
                <div class="field"><label>Product Type *</label>
                    <select name="type"><?php $__currentLoopData = ['standard','combo','digital','service']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($type); ?>" <?php if(old('type', $product->type)===$type): echo 'selected'; endif; ?>><?php echo e(ucfirst($type)); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
                </div>
                <div class="field"><label>Product Code *</label><input name="code" value="<?php echo e(old('code', $product->code ?: strtoupper(str()->random(8)))); ?>" required></div>
                <div class="field"><label>Brand *</label><select name="brand_id" required><option value="">Select a brand</option><?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($brand->id); ?>" <?php if(old('brand_id', $product->brand_id)==$brand->id): echo 'selected'; endif; ?>><?php echo e($brand->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Category *</label><select name="category_id" required><option value="">Select a category</option><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($category->id); ?>" <?php if(old('category_id', $product->category_id)==$category->id): echo 'selected'; endif; ?>><?php echo e($category->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Product Unit *</label><select name="unit_id" required><option value="">Select a unit</option><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($unit->id); ?>" <?php if(old('unit_id', $product->unit_id)==$unit->id): echo 'selected'; endif; ?>><?php echo e($unit->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Sale Unit</label><select name="sale_unit_id"><option value="">Select a sale unit</option><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($unit->id); ?>" <?php if(old('sale_unit_id', $product->sale_unit_id)==$unit->id): echo 'selected'; endif; ?>><?php echo e($unit->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Purchase Unit</label><select name="purchase_unit_id"><option value="">Select a purchase unit</option><?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($unit->id); ?>" <?php if(old('purchase_unit_id', $product->purchase_unit_id)==$unit->id): echo 'selected'; endif; ?>><?php echo e($unit->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Warehouse</label><select name="warehouse_id"><option value="">Select</option><?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($warehouse->id); ?>" <?php if(old('warehouse_id', $product->warehouse_id)==$warehouse->id): echo 'selected'; endif; ?>><?php echo e($warehouse->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                <div class="field"><label>Purchase Cost *</label><input name="cost" value="<?php echo e(old('cost', number_format(($product->cost_cents ?? 0)/100, 2, '.', ''))); ?>" required></div>
                <div class="field"><label>Selling Price *</label><input name="price" value="<?php echo e(old('price', number_format(($product->price_cents ?? 0)/100, 2, '.', ''))); ?>" required></div>
                <div class="field"><label>Alert Quantity</label><input type="number" name="alert_qty" min="0" value="<?php echo e(old('alert_qty', $product->alert_qty ?? 0)); ?>"></div>
            </div>
            <div class="field"><label>Product Details</label><textarea name="description" rows="4"><?php echo e(old('description', $product->description)); ?></textarea></div>
        </section>
        <div>
            <section class="card">
                <h2>Product Image</h2>
                <?php if($product->image): ?><img src="<?php echo e(asset('storage/'.$product->image)); ?>" alt="" style="width:120px;height:120px;object-fit:cover;border-radius:12px"><?php endif; ?>
                <div class="field"><label>Upload image (PNG, JPG, WEBP, max 5MB)</label><input type="file" name="image" accept="image/png,image/jpeg,image/webp"></div>
                <?php if($product->image): ?><label><input type="checkbox" name="remove_image" value="1"> Remove current image</label><?php endif; ?>
            </section>
            <section class="card" style="margin-top:12px">
                <h2>Additional Information</h2>
                <div class="form-grid">
                    <div class="field"><label>Tax</label><select name="tax_id"><option value="">No tax</option><?php $__currentLoopData = $taxes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tax): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($tax->id); ?>" <?php if(old('tax_id', $product->tax_id)==$tax->id): echo 'selected'; endif; ?>><?php echo e($tax->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="field"><label>Tax Method</label><select name="tax_method"><option value="exclusive" <?php if(old('tax_method', $product->tax_method)==='exclusive'): echo 'selected'; endif; ?>>Exclusive</option><option value="inclusive" <?php if(old('tax_method', $product->tax_method)==='inclusive'): echo 'selected'; endif; ?>>Inclusive</option></select></div>
                </div>
                <label><input type="hidden" name="is_active" value="0"><input type="checkbox" name="is_active" value="1" <?php if(old('is_active', $product->is_active ?? true)): echo 'checked'; endif; ?>> Active</label><br>
                <label><input type="checkbox" name="featured_in_pos" value="1" <?php if(old('featured_in_pos', $product->featured_in_pos)): echo 'checked'; endif; ?>> Featured product will be displayed in POS</label><br>
                <label><input type="checkbox" name="has_serial" value="1" <?php if(old('has_serial', $product->has_serial)): echo 'checked'; endif; ?>> This product has Serial or IMEI number</label><br>
                <label><input type="checkbox" name="has_batch" value="1" <?php if(old('has_batch', $product->has_batch)): echo 'checked'; endif; ?>> This product has batch and expired date</label><br>
                <label><input type="checkbox" name="has_variant" value="1" <?php if(old('has_variant', $product->has_variant)): echo 'checked'; endif; ?>> This product has variant</label><br>
                <label><input type="checkbox" name="has_promo" value="1" <?php if(old('has_promo', $product->promo_price_cents !== null)): echo 'checked'; endif; ?>> Add Promotional Price</label>
                <div class="field"><label>Promotional price</label><input name="promo_price" value="<?php echo e(old('promo_price', $product->promo_price_cents !== null ? number_format($product->promo_price_cents/100, 2, '.', '') : '')); ?>"></div>
            </section>
        </div>
    </div>
    <section class="card" style="margin-top:12px">
        <h2>Variants</h2>
        <?php for($i=0;$i<3;$i++): ?>
            <?php $variant = $variants[$i] ?? null; ?>
            <div class="form-grid">
                <input type="hidden" name="variants[<?php echo e($i); ?>][id]" value="<?php echo e($variant->id ?? ''); ?>">
                <div class="field"><label>Variant name</label><input name="variants[<?php echo e($i); ?>][name]" value="<?php echo e($variant->name ?? ''); ?>"></div>
                <div class="field"><label>SKU</label><input name="variants[<?php echo e($i); ?>][sku]" value="<?php echo e($variant->sku ?? ''); ?>"></div>
                <div class="field"><label>Price</label><input name="variants[<?php echo e($i); ?>][price]" value="<?php echo e(isset($variant) ? number_format($variant->price_cents/100,2,'.','') : ''); ?>"></div>
                <div class="field"><label>Stock</label><input name="variants[<?php echo e($i); ?>][stock_qty]" value="<?php echo e($variant->stock_qty ?? ''); ?>"></div>
            </div>
        <?php endfor; ?>
        <button class="btn primary" type="submit">Submit Product</button>
        <a class="btn" href="<?php echo e(route('products.index')); ?>">Cancel</a>
    </section>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/products/form.blade.php ENDPATH**/ ?>