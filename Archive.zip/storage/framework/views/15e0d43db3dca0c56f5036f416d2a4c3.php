<?php $__env->startSection('content'); ?>
<div class="page-title"><div><h1>Payrolls</h1></div></div>
<div class="grid-2">
<section class="card"><form method="post" action="<?php echo e(route('payrolls.store')); ?>" data-once><?php echo csrf_field(); ?>
    <div class="field"><label>Employee</label><select name="employee_id"><?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($employee->id); ?>"><?php echo e($employee->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
    <div class="field"><label>Month</label><input name="month" placeholder="2026-10" required></div>
    <div class="field"><label>Amount</label><input name="amount" required></div>
    <div class="field"><label>Paid on</label><input type="date" name="paid_on" value="<?php echo e(now()->toDateString()); ?>"></div>
    <div class="field"><label>Note</label><input name="note"></div>
    <button class="btn primary">Pay salary</button>
</form></section>
<section class="card"><table><thead><tr><th>Month</th><th>Employee</th><th>Paid</th><th>Amount</th></tr></thead>
<tbody><?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><tr><td><?php echo e($row->month); ?></td><td><?php echo e($row->employee->name); ?></td><td><?php echo e($row->paid_on->format('d M Y')); ?></td><td><?php echo \App\Support\Money::format((int) ($row->amount_cents), $moneySymbol ?? '$'); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4" class="empty">No payroll yet.</td></tr><?php endif; ?></tbody></table><?php echo e($rows->links()); ?></section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/hrm/payrolls.blade.php ENDPATH**/ ?>