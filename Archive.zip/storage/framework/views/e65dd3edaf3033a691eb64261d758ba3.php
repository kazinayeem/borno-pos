<?php $__env->startSection('content'); ?>
<div class="page-title"><div><div class="crumbs">Purchase › Purchases</div><h1>Purchases</h1></div><a class="btn primary" href="<?php echo e(route('purchases.create')); ?>">+ Add Purchase</a></div>
<section class="card">
    <form method="get"><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Search reference or supplier"></form>
    <table>
        <thead><tr><th>SL</th><th>Date</th><th>Reference</th><th>Supplier</th><th>Total</th><th>Paid</th><th>Due</th><th></th></tr></thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $purchases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($purchase->purchased_on->format('d-m-Y')); ?></td>
                <td><a href="<?php echo e(route('purchases.show', $purchase)); ?>"><?php echo e($purchase->reference); ?></a></td>
                <td><?php echo e($purchase->supplier->name ?? '—'); ?></td>
                <td><?php echo \App\Support\Money::format((int) ($purchase->grand_cents), $moneySymbol ?? '$'); ?></td>
                <td><?php echo \App\Support\Money::format((int) ($purchase->paid_cents), $moneySymbol ?? '$'); ?></td>
                <td><?php echo \App\Support\Money::format((int) ($purchase->dueCents()), $moneySymbol ?? '$'); ?></td>
                <td><a href="<?php echo e(route('purchases.show', $purchase)); ?>">View</a></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" class="empty">No purchases yet.</td></tr>
        <?php endif; ?>
        </tbody>
    </table>
    <div class="pager"><?php echo e($purchases->links()); ?></div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/mohammadalinayeem/Project & Code/borno-pos/resources/views/purchases/index.blade.php ENDPATH**/ ?>